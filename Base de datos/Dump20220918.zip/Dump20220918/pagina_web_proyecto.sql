CREATE DATABASE  IF NOT EXISTS `pagina_web` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `pagina_web`;
-- MySQL dump 10.13  Distrib 8.0.29, for Linux (x86_64)
--
-- Host: localhost    Database: pagina_web
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proyecto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo_proyecto` varchar(100) NOT NULL,
  `logo_proyecto` varchar(100) DEFAULT NULL,
  `titulo` varchar(300) DEFAULT NULL,
  `numero_expediente` varchar(50) DEFAULT NULL,
  `fecha_inicio` varchar(20) DEFAULT NULL,
  `cif` varchar(20) DEFAULT NULL,
  `duracion` varchar(20) DEFAULT NULL,
  `resumen` varchar(2000) DEFAULT NULL,
  `logo_menu` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto`
--

LOCK TABLES `proyecto` WRITE;
/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` VALUES (1,'Integración de Redes IoT en entornos inteligentes basados en SDN/NFV y redes 5G','../imagenes_subidas/logo_proyecto_1657109137.2304.jpg','IRIS-CM','CM/JIN/2019-039','01/01/2020','Q2818018J','24 meses','  Actualmente, las redes de comunicaciones son cruciales para interconectar un mundo digitalizado formado por un gran número de dispositivos heterogéneos al cual se le conoce como Internet de las Cosas (IoT-Internet of Things). Por este motivo, la quinta generación de red móvil (5G) prevé la integración de estos dispositivos IoT en redes inteligentes apoyadas en las tecnologías de las redes definidas por software (SDN - Software-Defined Networking) y la virtualización de funciones de red (NFV-Network Function Virtualization). Sin embargo, esta la integración de IoT y SDN/NFV no es todavía posible debido a las limitaciones de energía, capacidad o del firmware/software de los dispositivos IoT. Por todo ello, el proyecto IRIS tiene como objetivo facilitar la integración de estas tecnologías mediante el estudio de protocolos y servicios inteligentes que permitan faciliten la configuración de red, el descubrimiento de recursos y servicios para hacer un uso adecuado y eficiente de ellos. Además, se estudiarán mecanismos de encaminamiento eficiente en entornos IoT de forma integrada con redes inteligentes basadas en SDN/NFVV, (como son las redes 5G). De esta manera, se pretende impulsar la integración del IoT con el núcleo de las redes de comunicaciones para ofrecer soluciones y servicios más avanzados que permitan continuar con la modernización de la sociedad. ','../imagenes_subidas/logo_menu_1657109137.237.png');
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-18 23:12:32
